#include <iostream>
#include "dado.h"
#include <string>
int main(int argc, char const *argv[])
{
	string player1;
	string player2;
	string player3;

    cout << "Entre o nome dos participantes: " << endl;
    
    player um("Alice");
    player dois("Bob");
    player tres("Carl"); 
    
    Dado tetrahedron(1, 3);
    Dado cube(1, 6);
    Dado octahedron(1, 8);
    Dado dodecahedron(1, 12);
    Dado icosahedron(1, 20);


    um.AumenteAgregado(tetrahedron.getValor());
    um.AumenteAgregado(cube.getValor());
    um.AumenteAgregado(octahedron.getValor());
    um.AumenteAgregado(dodecahedron.getValor());
    um.AumenteAgregado(icosahedron.getValor());

    dois.AumenteAgregado(tetrahedron.getValor());
    dois.AumenteAgregado(cube.getValor());
    dois.AumenteAgregado(octahedron.getValor());
    dois.AumenteAgregado(dodecahedron.getValor());
    dois.AumenteAgregado(icosahedron.getValor());

    tres.AumenteAgregado(tetrahedron.getValor());
    tres.AumenteAgregado(cube.getValor());
    tres.AumenteAgregado(octahedron.getValor());
    tres.AumenteAgregado(dodecahedron.getValor());
    tres.AumenteAgregado(icosahedron.getValor());

    cout << um.getNome() << " ficou com o agregado de: " << um.getAgregado() << endl;
    cout << dois.getNome() << " ficou com o agregado de: " << dois.getAgregado() << endl;
    cout << tres.getNome() << " ficou com o agregado de: " << tres.getAgregado() << endl;
    	

	return 0;
}